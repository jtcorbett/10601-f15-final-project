function out = classify2(model, data)
  for i=1:size(data)
    out(i, 1) = 1;
  end
end